﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NV1.Models
{
    enum PohlaviEnum
    {
        Jine = 0,
        Muz = 1,
        Zena = 2
    }
}
